count = 0 
i = N
while(i > 0):
  for j in range(i):
    count+=1
  i /= 2