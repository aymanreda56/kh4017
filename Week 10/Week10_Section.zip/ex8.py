def fun(n):
    if (n < 5):
        print("Programming")
    else:
        for i in range(n):
            print(i, end= " ")
    
#best case O(1)
#O(n)

