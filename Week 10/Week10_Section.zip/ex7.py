def function(n):
    i = 1
    s = 1
    while (s < n):
        s = s + i
        i+=1
