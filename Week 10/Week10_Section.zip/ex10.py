def fun(n):
    i = 0
    while i*i < n:
        print("programming")
        i += 1
