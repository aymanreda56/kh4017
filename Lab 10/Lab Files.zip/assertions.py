# Write a function that takes a mark
# and returns the grade
# mark >= 85 --> A
# 85 > mark >= 75 --> B
# 75 > Mark >= 65 --> C
# 65 > Mark >= 50 --> D
# else F

# Let's discuss all side cases, handle them via assertions








# Write a program that:
# 1- Opens a file called "grade.txt"
# 2- Read its content
# 3- Reads the grade score and calculates the grade Letter
# 4- Displays the grade (A or B or C or D or F)
# 5- Writes the Letter in another file called "Letter.txt"

# HANDLE ALL SIDE CASES via Assert